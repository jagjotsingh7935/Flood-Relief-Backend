from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import *
from .serializers import *
from django.utils import timezone
from django.db.models import Q
from .google_api import schedule_meeting
from django.conf import settings
import razorpay

from django.db import transaction
from django.core.mail import send_mail
from django.utils import timezone
from datetime import datetime, timedelta
import os
from rest_framework.pagination import PageNumberPagination


from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
import time
from django.contrib.auth import authenticate, login
from rest_framework.permissions import AllowAny
from django.contrib.auth import logout




from django.http import FileResponse
from django.conf import settings
import os



from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

from django.http import HttpResponseRedirect, HttpResponse
from google_auth_oauthlib.flow import InstalledAppFlow
import json
from django.core.cache import cache


User = get_user_model()


class FeesCreateView(APIView):

    permission_classes = [IsAuthenticated]

    def post(self,request):
        serializer = FeesModelSerializer(data=request.data)
        
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class FeesShowView(APIView):


    def get(self, request):
        try:
            fees = FeesModel.objects.latest('id')
            serializer = FeesModelSerializer(fees)
            return Response(serializer.data)
        except FeesModel.DoesNotExist:
            return Response({"error": "No fee configuration found"}, status=status.HTTP_404_NOT_FOUND)

class FeesShowBackendView(APIView):


    def get(self, request):
        try:
            fees = FeesModel.objects.latest('id')
            serializer = FeesModelSerializer(fees)
            return Response(serializer.data)
        except FeesModel.DoesNotExist:
            return Response({"error": "No fee configuration found"}, status=status.HTTP_404_NOT_FOUND)
        
        
class FeesShowAllView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request):
        fees = FeesModel.objects.all()
        serializer = FeesModelSerializer(fees, many=True)
        return Response(serializer.data)
    


#-----------------------------------------------------------------user-----------------------------------------------------------
class UserSlotView(APIView):

    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        print("[DEBUG] Incoming POST request with data:", request.data)
        serializer = UserSlotSerializer(data=request.data)
        if not serializer.is_valid():
            print("[ERROR] Serializer validation failed:", serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        try:
            # First save the user_slot
            user_slot = serializer.save()
            
            # Then set payment status based on booking type
            if user_slot.isOnline:
                user_slot.payment_status = 'on hold'
                user_slot.save()
                print("[DEBUG] Online user slot created successfully with on hold status:", user_slot.id)
            elif user_slot.isOffline:
                user_slot.payment_status = 'on hold'
                user_slot.save()
                print("[DEBUG] Offline user slot created successfully with success status:", user_slot.id)
            
            UserSlotLogModel.objects.create(
                user=user,
                userSlot=user_slot,
                action='create',
                description='User Slot Created'
            )
            print("[DEBUG] Log entry created for user slot creation.")
            
            self._send_confirmation_email(user_slot)
            print("[DEBUG] Confirmation email sent successfully.")


            

            ##########################################
        
           
            
            return Response({
                'user_slot': UserSlotSerializer(user_slot).data,
            }, status=status.HTTP_201_CREATED)
        except Exception as e:
            print("[ERROR] Failed to process request:", str(e))
            return Response(
                {"error": f"Failed to process request: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


    def put(self, request, pk=None):
        user = request.user
        print("[DEBUG] Incoming PUT request with data:", request.data, "for slot ID:", pk)
        if not pk:
            return Response({"error": "Slot ID is required"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user_slot = UserSlot.objects.get(pk=pk)
            serializer = UserSlotSerializer(user_slot, data=request.data, partial=True)
            if not serializer.is_valid():
                print("[ERROR] Serializer validation failed:", serializer.errors)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
            # Check if payment_status is being updated to 'pending'
            if 'payment_status' in request.data and request.data['payment_status'] == 'pending':
                # Reset the meet_link and make the slot available again
                user_slot.meet_link = None
                user_slot.payment_status = 'pending'
                user_slot.save()
                
                UserSlotLogModel.objects.create(
                    user=user,
                    userSlot=user_slot,
                    action='update',
                    description='User Slot Updated - Payment status set to pending, slot made available again'
                )
                
                return Response({
                    'message': 'Slot updated successfully, payment status set to pending, and slot made available again',
                    'status': 'success',
                }, status=status.HTTP_200_OK)
            
            updated_slot = serializer.save()
            print("[DEBUG] User slot updated successfully:", updated_slot.id)
            
            UserSlotLogModel.objects.create(
                user=user,
                userSlot=updated_slot,
                action='update',
                description='User Slot Updated'
            )
            print("[DEBUG] Log entry created for user slot update.")
            
            if updated_slot.isOnline and (
                'startTime' in request.data or
                'endTime' in request.data or
                'date' in request.data
            ):
                try:
                    meet_link = self._generate_meet_link(updated_slot)
                    print(f"[DEBUG] Updated slot: {updated_slot}")
                    print(f"[DEBUG] Meet link: {meet_link}")                    
                    updated_slot.meet_link = meet_link
                    updated_slot.save()
                    print("[DEBUG] Meeting link regenerated successfully:", meet_link)
                except Exception as e:
                    if "Redirect to Google OAuth" in str(e):
                        return Response({
                            'message': 'OAuth authentication required',
                            'status': 'redirect',
                            'redirect_url': str(e).split(": ")[1]
                        }, status=status.HTTP_302_FOUND)
                    print("[ERROR] Meet link regeneration failed:", str(e))
                    return Response({
                        'message': 'Slot updated but meet link regeneration failed',
                        'status': 'success',
                        'meet_link_status': 'failed',
                        'meet_link_error': str(e)
                    }, status=status.HTTP_200_OK)
            else:
                print("[DEBUG] No need to regenerate meet link as slot is not online or required fields are not updated.")
                
        # Send updated confirmation email for both online and offline slots
            self._updated_confirmation_email(updated_slot)
            print("[DEBUG] Update confirmation email sent successfully.")

        
            return Response(UserSlotSerializer(updated_slot).data, status=status.HTTP_200_OK)
        except UserSlot.DoesNotExist:
            print("[ERROR] Slot not found for ID:", pk)
            return Response({"error": "Slot not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print("[ERROR] Failed to update slot:", str(e))
            return Response(
                {"error": f"Failed to update slot: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def _generate_meet_link(self, user_slot):
        print("[DEBUG] Generating meet link for slot ID:", user_slot.id)
        meeting_data = {
            'firstName': user_slot.firstName,
            'lastName': user_slot.lastName,
            'email': user_slot.email,
            'isOnline': user_slot.isOnline,
            'isOffline': user_slot.isOffline,
            'startTime': user_slot.startTime,
            'endTime': user_slot.endTime,
            'date': user_slot.date,
            'message': user_slot.message,
            'meet_link': user_slot.meet_link,
            'created_at': user_slot.created_at,
            'payment_status': user_slot.payment_status,
        }
        try:
            return schedule_meeting(meeting_data)
        except Exception as e:
            if "Redirect to Google OAuth" in str(e):
                raise Exception(f"Redirect to Google OAuth: {str(e).split(': ')[1]}")
            raise e
    
    def _send_confirmation_email(self, user_slot, is_update=False):
        try:
            print("[DEBUG] Sending confirmation email to:", user_slot.email)
            subject = "Booking Confirmation Update" if is_update else "Booking Status"
            from_email = settings.EMAIL_HOST_USER
            recipient_list = [user_slot.email]

            fee_config = FeesModel.objects.latest('id')
            amount = fee_config.amountOnline if user_slot.isOnline else fee_config.amountOffline
            
            # Common CSS styles for both email templates
            styles = """
                @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap');
                
                body {
                    font-family: 'Roboto', Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    background-color: #f4f4f4;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    max-width: 600px;
                    margin: 30px auto;
                    background-color: white;
                    border-radius: 12px;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                    overflow: hidden;
                }
                .header {
                    
                    text-align: center;
                    padding: 20px;
                }
                .header h1{
                    color: #026277
                }
                .header img {
                    max-width: 300px;
                    height: auto;
                }
                .content {
                    padding: 30px;
                    background-color: #ffffff;
                    border-top: 4px solid #026277
                }
                .details {
                    border-left: 4px solid #026277;
                    background-color: #f9f9f9;
                    padding: 20px;
                    margin: 20px 0;
                    border-radius: 0 8px 8px 0;
                }
                .details p {
                    margin: 10px 0;
                    color: #555;
                }
                .details strong {
                    color: #026277;
                    min-width: 100px;
                    display: inline-block;
                }
                .system-notice {
                    font-family: 'Courier New', monospace;
                    color: #666;
                    font-size: 0.9em;
                    text-align: center;
                    margin: 20px 0;
                    padding: 10px;
                    background-color: #f5f5f5;
                    border-radius: 5px;
                }
                .footer {
                    background-color: #f4f4f4;
                    text-align: center;
                    padding: 20px;
                    font-size: 0.9em;
                    color: #777;
                }
                .important-notice {
                    color: #666666;
                    font-weight: bold;
                    margin: 15px 0;
                    text-align: center;
                }
            """

            consultation_type = "online" if user_slot.isOnline else "offline"
            amount_text = f"<p><strong>Consultation Fee:</strong> ₹{amount}</p>" if amount else ""
            
            message = f"""
            <html>
                <head>
                    <style>{styles}</style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <img src="https://metabolicresetwithbob.com/static/assets/logo-B9l4SiOc.png" alt="Metabolic Reset With Bob">
                            <h1>Consultation {subject}</h1>
                        </div>
                        <div class="content">
                            <p>Dear {user_slot.firstName},</p>
                            <p>Your {consultation_type} consultation slot has been put on hold. Please complete the payment process to confirm your booking.</p>
                            
                            <div class="details">
                                <p><strong>Date:</strong> {user_slot.date.strftime('%Y-%m-%d')}</p>
                                <p><strong>Time:</strong> {user_slot.startTime.strftime('%I:%M %p')} - {user_slot.endTime.strftime('%I:%M %p')}</p>
                                {amount_text}
                            </div>

            
                            
                            <p class="important-notice">Note: The consultation fee is non-refundable but can be rescheduled.</p>
                        </div>
                        <div class="footer">
                            <p>Best regards,</p>
                            <p><strong>Bob Chris</strong></p>
                            <p>Metabolic Reset With Bob</p>
                            <div class="system-notice">
                                This is a system-generated email. Please do not reply to this message.
                            </div>
                        </div>
                    </div>
                </body>
            </html>
            """
            
            send_mail(subject, message, from_email, recipient_list, fail_silently=False, html_message=message)
            print("[DEBUG] Email sent successfully to:", user_slot.email)
        except Exception as e:
            print("[ERROR] Failed to send confirmation email:", str(e))


    def _updated_confirmation_email(self, user_slot, is_update=True):
        try:
            print("[DEBUG] Sending update confirmation email to:", user_slot.email)
            subject = "Booking Update Confirmation"
            from_email = settings.EMAIL_HOST_USER
            recipient_list = [user_slot.email]
            
            # Updated CSS and HTML template
            styles = """
                @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap');
                
                body {
                    font-family: 'Roboto', Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    background-color: #f4f4f4;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    max-width: 600px;
                    margin: 30px auto;
                    background-color: white;
                    border-radius: 12px;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                    overflow: hidden;
                }
                .header {
                
                    text-align: center;
                    padding: 20px;
                }

                .header h1{
                    color: #026277;
                }
                .header img {
                    max-width: 300px;
                    height: auto;
                    
                }
                .content {
                    padding: 30px;
                    background-color: #ffffff;
                    border-top: 4px solid #026277

                }
                .details {
                    background-color: #f9f9f9;
                    border-left: 4px solid #026277;
                    padding: 20px;
                    margin: 20px 0;
                    border-radius: 0 8px 8px 0;
                }
                .details p {
                    margin: 10px 0;
                    color: #555;
                }
                .details strong {
                    color: #026277;
                    min-width: 100px;
                    display: inline-block;
                }
                .meeting-link {
                    display: block;
                    text-align: center;
                    margin: 20px 0;
                }
                .meeting-link a {
                    background-color: #026277;
                    color: white;
                    text-decoration: none;
                    padding: 12px 24px;
                    border-radius: 6px;
                    font-weight: bold;
                    transition: background-color 0.3s ease;
                }
                .system-notice {
                    font-family: 'Courier New', monospace;
                    color: #666;
                    font-size: 0.9em;
                    text-align: center;
                    margin: 20px 0;
                    padding: 10px;
                    background-color: #f5f5f5;
                    border-radius: 5px;
                }
                .footer {
                    background-color: #f4f4f4;
                    text-align: center;
                    padding: 20px;
                    font-size: 0.9em;
                    color: #777;
                }

                .clinic-info {
                    background-color: #e8f5e9;
                    border-radius: 8px;
                    padding: 15px;
                    margin-top: 20px;
                    text-align: center;
                }
                .important-notice {
                    color: #666666;
                    font-weight: bold;
                    margin: 15px 0;
                    text-align: center;
                }
                .important-notice2 {
                    color: #666666;
                    
                    margin: 12px 0;
                    text-align: center;
                
                }
            """

            consultation_type = "online" if user_slot.isOnline else "offline"
            meeting_link = f"<div class='meeting-link'><a href='{user_slot.meet_link}'>Join Meeting</a></div>" if user_slot.isOnline else ""

            # Conditional content based on appointment type
            if user_slot.isOnline:
                specific_content = """
                <p class="important-notice2">Please ensure you have a stable internet connection and are in a quiet environment for your consultation. If you need to reschedule, please contact our office at least 24 hours in advance.</p>
                <p class="important-notice">Note: The consultation fee is non-refundable but can be rescheduled.</p>
                """
            else:
                specific_content = """
                <div class="clinic-info">
                    <p>Please arrive at our clinic 10 minutes before your scheduled time.</p>
                    <p><strong>Clinic Address:</strong> H.NO.1920, Sector 34-D, (Near Radio Station)
                Chandigarh - 160034, INDIA</p>
                </div>
                
                <p class="important-notice2">We look forward to providing you with personalized homeopathic care.</p>
                <p class="important-notice">Note: The consultation fee is non-refundable but can be rescheduled.</p>
                """
                
            message = f"""
            <html>
                <head>
                    <style>{styles}</style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <img src="https://metabolicresetwithbob.com/static/assets/logo-B9l4SiOc.png" alt="Metabolic Reset With Bob">
                            <h1>Consultation Update Confirmation</h1>
                        </div>
                        <div class="content">
                            <p>Dear {user_slot.firstName},</p>
                            <p>Your {consultation_type} consultation details have been updated:</p>
                            
                            <div class="details">
                                <p><strong>New Date:</strong> {user_slot.date.strftime('%Y-%m-%d')}</p>
                                <p><strong>New Time:</strong> {user_slot.startTime.strftime('%I:%M %p')} - {user_slot.endTime.strftime('%I:%M %p')}</p>
                            </div>

                            {meeting_link if user_slot.isOnline else ""}
                            
                            {specific_content}

                        </div>
                        <div class="footer">
                            <p>Best regards,</p>
                            <p><strong>Bob Chris</strong></p>
                            <p>Metabolic Reset With Bob</p>
                            <div class="system-notice">
                                This is a system-generated email. Please do not reply to this message.
                            </div>
                        </div>
                    </div>
                </body>
            </html>
            """
                
            send_mail(subject, message, from_email, recipient_list, fail_silently=False, html_message=message)
            print("[DEBUG] Update confirmation email sent successfully to:", user_slot.email)
        except Exception as e:
            print("[ERROR] Failed to send update confirmation email:", str(e))


# Delete For only pending payment status

    def delete(self, request, pk=None):
        user = request.user
        print("[DEBUG] Incoming DELETE request for slot ID:", pk)
        
        if not pk:
            return Response({"error": "Slot ID is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            user_slot = UserSlot.objects.get(pk=pk)
            
            # Check if the payment_status is 'pending'
            if user_slot.payment_status != 'pending':
                return Response(
                    {"error": "Cannot delete slot. Payment status is not 'pending'."},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Log the deletion
            UserSlotLogModel.objects.create(
                user=user,
                userSlot=user_slot,
                action='delete',
                description=f'User Slot Deleted - Slot ID: {user_slot.id}, Payment Status: {user_slot.payment_status}'
            )
            
            # Delete the slot
            user_slot.delete()
            
            return Response(
                {"message": "Slot deleted successfully"},
                status=status.HTTP_204_NO_CONTENT
            )
        
        except UserSlot.DoesNotExist:
            print("[ERROR] Slot not found for ID:", pk)
            return Response({"error": "Slot not found"}, status=status.HTTP_404_NOT_FOUND)
        
        except Exception as e:
            print("[ERROR] Failed to delete slot:", str(e))
            return Response(
                {"error": f"Failed to delete slot: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class UserSlotFrontendView(APIView):


    permission_classes = [AllowAny]


    def post(self, request):
        serializer = UserSlotSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Wrap the entire operation in a transaction
        with transaction.atomic():
            try:
                # Save the user slot
                user_slot = serializer.save()
            
                fee_config = FeesModel.objects.latest('id')  # Assuming newer entries should override older ones
                amount_online = fee_config.amountOnline
                amount_offline = fee_config.amountOffline

                
                # Initialize Razorpay client
                client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))

                client.set_app_details({
                    "title": "Django",
                    "version": "5.1.4"
                })                
                
                # Set amount based on meeting type
                amount = amount_online if user_slot.isOnline else amount_offline  # ₹500 for online, ₹1000 for offline

                print("####################################################################################",amount)
                
                # Create Razorpay order
                razorpay_order = client.order.create({
                    'amount': int(amount * 100),  # Amount in paise
                    'currency': 'INR',
                    'payment_capture': 1,
                    'notes': {
                        'user_slot_id': user_slot.id,
                        'name': f"{user_slot.firstName} {user_slot.lastName}",
                        'email': user_slot.email,
                        'phone': user_slot.phoneNumber
                    }
                })


                
                # Create payment record
                payment = Payment.objects.create(
                    user_slot=user_slot,
                    razorpay_order_id=razorpay_order['id'],
                    amount=amount
                )
                
                return Response({
                    'user_slot': UserSlotSerializer(user_slot).data,
                    'payment': {
                        'order_id': razorpay_order['id'],
                        'amount': amount,
                        'currency': 'INR'
                    }
                }, status=status.HTTP_201_CREATED)
                
            except Exception as e:
                # The transaction will automatically roll back in case of any exception
                return Response(
                    {"error": f"Failed to process request: {str(e)}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )


class UserShowView(APIView):


    permission_classes = [IsAuthenticated]


    def get(self, request):
        slot = UserSlot.objects.all()
        serializer = UserSlotSerializer(slot, many=True,context={'request': request})
        return Response(serializer.data)
    

class UserShow_filterView(APIView):


    permission_classes = [IsAuthenticated]


    def get(self, request):
        first_name = request.query_params.get('firstName', '').strip()
        last_name = request.query_params.get('lastName', '').strip()
        
        queryset = UserSlot.objects.all()
        
        if first_name:
            queryset = queryset.filter(firstName__iexact=first_name)
        if last_name:
            queryset = queryset.filter(lastName__iexact=last_name)

        if not queryset.exists():
            return Response(
                {"message": "No records found matching the search criteria"},
                status=status.HTTP_404_NOT_FOUND
            )

        serializer = UserSlotSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    

#---------------------------------------------------------------Doctor-------------------------------------------------------------------

class DoctorScheduleTemplateView(APIView):


    # permission_classes=[IsAuthenticated]


    def post(self, request):
        user = request.user
        serializer = DoctorScheduleTemplateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            DoctorLogModel.objects.create(
                user=user,
                doctor = serializer.instance,
                action='Create',
                description ='Doctor Schedule Created',
            )
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request):
        schedules = DoctorScheduleTemplate.objects.all()
        serializer = DoctorScheduleTemplateSerializer(schedules, many=True)
        return Response(serializer.data)

class DoctorScheduleTemplateEditView(APIView):


    permission_classes=[IsAuthenticated]


    def put(self, request, pk):
        user = request.user
        schedule = get_object_or_404(DoctorScheduleTemplate, pk=pk)
        serializer = DoctorScheduleTemplateSerializer(schedule, data=request.data)
        if serializer.is_valid():
            serializer.save()
            
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class DoctorScheduleExceptionView(APIView):


    permission_classes=[IsAuthenticated]



    def post(self, request):
        user = request.user
        serializer = DoctorScheduleExceptionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            DoctorExceptionLogModel.objects.create(
                user=user,
                doctor = serializer.instance,
                action='create',
                description ='Doctor Schedule Exception Updated',
                )
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request):
        exceptions = DoctorScheduleException.objects.all()
        serializer = DoctorScheduleExceptionSerializer(exceptions, many=True)
        return Response(serializer.data)
    



class DoctorScheduleExceptionEditView(APIView):


    permission_classes=[IsAuthenticated]


    def patch(self, request, id=None):
        user=request.user
        if not id:
            return Response({"error": "ID is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            time_slot = DoctorExceptionTimeSlot.objects.get(id=id)
        except DoctorExceptionTimeSlot.DoesNotExist:
            return Response({"error": "No time slot found for the given ID."}, status=status.HTTP_404_NOT_FOUND)

        serializer = DoctorExceptionTimeSlotSerializer(time_slot, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            doctor_schedule_exception = time_slot.exception_day
            DoctorExceptionLogModel.objects.create(
                user=user,
                doctor = doctor_schedule_exception,
                action='update',
                description ='Doctor Schedule Exception Updated',
                )
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  



    def delete(self,request,id=None):
        user=request.user
        if not id:
            return Response({"error": "ID is required."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            time_slot = DoctorExceptionTimeSlot.objects.get(id=id)
        except DoctorExceptionTimeSlot.DoesNotExist:
            return Response({"error": "No time slot found for the given ID."}, status=status.HTTP_404_NOT_FOUND)
        time_slot.delete()
        doctor_schedule_exception = time_slot.exception_day
        DoctorExceptionLogModel.objects.create(
            user=user,
            doctor = doctor_schedule_exception,
            action='delete',    
            description ='Doctor Schedule Exception Deleted',
            )
        return Response({"message": "Doctor Schedule Exception deleted successfully"}, status=status.HTTP_200_OK)
    



class DoctorScheduleHolidayDeleteView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, date):
        try:
            with transaction.atomic():
                # Fetch the holiday exception for the given date
                exception = DoctorScheduleException.objects.get(date=date, is_holiday=True)

                # Log the deletion before actually deleting the exception
                DoctorExceptionLogModel.objects.create(
                    user=request.user,
                    doctor=exception,  # Ensure this is the correct related name
                    action='delete',
                    description=f'Holiday deleted for {date}'
                )

                # Now delete the exception
                exception.delete()

            return Response(
                {"message": "Holiday deleted successfully"},
                status=status.HTTP_204_NO_CONTENT
            )

        except DoctorScheduleException.DoesNotExist:
            return Response(
                {"error": "No holiday found for this date"},
                status=status.HTTP_404_NOT_FOUND
            )
    


class DoctorTimeSlotDeleteView(APIView):

    # permission_classes = [IsAuthenticated]

    def delete(self, request, pk=None):
        user = request.user
        
        # Check if the time slot ID is provided
        if not pk:
            return Response(
                {"error": "Time slot ID is required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            # Fetch the time slot to be deleted
            time_slot = get_object_or_404(DoctorTimeSlot, id=pk)
            
            # Log the deletion action
            DoctorLogModel.objects.create(
                user=user,
                doctor=time_slot.schedule,  # Associate with the schedule template
                action='delete',
                description=f'Time slot deleted - Start Time: {time_slot.startTime}, End Time: {time_slot.endTime}'
            )
            
            # Delete the time slot
            time_slot.delete()
            
            return Response(
                {"message": "Time slot deleted successfully"},
                status=status.HTTP_204_NO_CONTENT
            )
        
        except DoctorTimeSlot.DoesNotExist:
            return Response(
                {"error": "Time slot not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        except Exception as e:
            return Response(
                {"error": f"Failed to delete time slot: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


#---------------------------------------------------Show Available Doctor Slots(All available)-------------------------------------------------


class AvailableDoctorSlotsView(APIView):


    permission_classes = [AllowAny]

    
    def get(self, request):
        # Get the date range
        start_date = datetime.strptime(
            request.query_params.get('start_date', datetime.now().date().strftime('%Y-%m-%d')),
            '%Y-%m-%d'
        ).date()
        
        # Get number of days to look ahead (default 7)
        days_ahead = int(request.query_params.get('days', 7))
        end_date = start_date + timedelta(days=days_ahead)

        available_slots = []
        current_date = start_date

        while current_date <= end_date:
            # Get the weekday number (0 = Monday, 1 = Tuesday, etc.)
            weekday = current_date.weekday()
            
            # First check if there's an exception for this date
            try:
                exception = DoctorScheduleException.objects.get(date=current_date)
                if not exception.is_holiday:  # If not a holiday, use exception slots
                    for slot in exception.time_slots.all():
                        # Check if the slot is already booked for this specific date
                        existing_bookings = UserSlot.objects.filter(
                            date=current_date,
                            startTime__lt=slot.endTime,
                            endTime__gt=slot.startTime
                        )
                        if not existing_bookings.exists():
                            available_slots.append({
                                'date': current_date,
                                'startTime': slot.startTime,
                                'endTime': slot.endTime,
                                'isOnline': slot.isOnline,
                                'isOffline': slot.isOffline
                            })
            except DoctorScheduleException.DoesNotExist:
                # No exception found, use regular template
                day_schedule = DoctorScheduleTemplate.objects.filter(
                    day_of_week=weekday,
                    is_active=True
                ).first()

                if day_schedule:
                    for slot in day_schedule.time_slots.all():
                        # Check if the slot is already booked for this specific date
                        existing_bookings = UserSlot.objects.filter(
                            date=current_date,
                            startTime__lt=slot.endTime,
                            endTime__gt=slot.startTime
                        )
                        if not existing_bookings.exists():
                            available_slots.append({
                                'date': current_date,
                                'startTime': slot.startTime,
                                'endTime': slot.endTime,
                                'isOnline': slot.isOnline,
                                'isOffline': slot.isOffline
                            })

            current_date += timedelta(days=1)

            print(current_date)

        # Sort slots by date and start time
        available_slots.sort(key=lambda x: (x['date'], x['startTime']))
        
        return Response(available_slots, status=status.HTTP_200_OK)
    

#---------------------------------------------------Show Available Doctor Slots(Online)-------------------------------------------------

class AvailableOnlineSlotsView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        start_date = datetime.strptime(
            request.query_params.get('start_date', datetime.now().date().strftime('%Y-%m-%d')),
            '%Y-%m-%d'
        ).date()
        days_ahead = int(request.query_params.get('days', 7))
        end_date = start_date + timedelta(days=days_ahead)
        available_slots = []
        current_date = start_date

        while current_date <= end_date:
            weekday = current_date.weekday()

            # Check for exceptions first
            exceptions = DoctorScheduleException.objects.filter(date=current_date)  # Use filter() to get all exceptions for the date
            for exception in exceptions:  # Iterate over each exception
                if not exception.is_holiday:  # Check if the exception is not a holiday
                    for slot in exception.time_slots.filter(isOnline=True):  # Only online slots
                        # Check for conflicting bookings
                        conflicting_bookings = UserSlot.objects.filter(
                            date=current_date,
                            startTime__lt=slot.endTime,
                            endTime__gt=slot.startTime,
                            isOnline=True,
                            payment_status__in=["success", "on hold"]  # Only successful bookings block the slot
                        )
                        if not conflicting_bookings.exists():
                            available_slots.append({
                                'date': current_date,
                                'startTime': slot.startTime,
                                'endTime': slot.endTime,
                                'isOnline': True,
                                'isOffline': False
                            })

            # If no exceptions exist for the date, use the regular schedule
            if not exceptions.exists():
                day_schedule = DoctorScheduleTemplate.objects.filter(
                    day_of_week=weekday,
                    is_active=True
                ).first()
                if day_schedule:
                    for slot in day_schedule.time_slots.filter(isOnline=True):  # Only online slots
                        # Check for conflicting bookings
                        conflicting_bookings = UserSlot.objects.filter(
                            date=current_date,
                            startTime__lt=slot.endTime,
                            endTime__gt=slot.startTime,
                            isOnline=True,
                            payment_status__in=["success", "on hold"]  # Only successful bookings block the slot
                        )
                        if not conflicting_bookings.exists():
                            available_slots.append({
                                'date': current_date,
                                'startTime': slot.startTime,
                                'endTime': slot.endTime,
                                'isOnline': True,
                                'isOffline': False
                            })

            current_date += timedelta(days=1)

        # Sort the slots
        available_slots.sort(key=lambda x: (x['date'], x['startTime']))
        return Response(available_slots, status=status.HTTP_200_OK)


#---------------------------------------------------Show Available Doctor Slots(Offline)-------------------------------------------------

class AvailableOfflineSlotsView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        start_date = datetime.strptime(
            request.query_params.get('start_date', datetime.now().date().strftime('%Y-%m-%d')),
            '%Y-%m-%d'
        ).date()
        days_ahead = int(request.query_params.get('days', 7))
        end_date = start_date + timedelta(days=days_ahead)
        available_slots = []
        current_date = start_date

        while current_date <= end_date:
            weekday = current_date.weekday()

            # Check for exceptions first
            exceptions = DoctorScheduleException.objects.filter(date=current_date)  # Use filter() to get all exceptions for the date
            for exception in exceptions:  # Iterate over each exception
                if not exception.is_holiday:  # Check if the exception is not a holiday
                    for slot in exception.time_slots.filter(isOffline=True):  # Only offline slots
                        # Check for conflicting bookings
                        conflicting_bookings = UserSlot.objects.filter(
                            date=current_date,
                            startTime__lt=slot.endTime,
                            endTime__gt=slot.startTime,
                            isOffline=True,
                            payment_status__in=["success", "on hold"]  # Only successful bookings block the slot
                        )
                        if not conflicting_bookings.exists():
                            available_slots.append({
                                'date': current_date,
                                'startTime': slot.startTime,
                                'endTime': slot.endTime,
                                'isOnline': False,
                                'isOffline': True
                            })

            # If no exceptions exist for the date, use the regular schedule
            if not exceptions.exists():
                day_schedule = DoctorScheduleTemplate.objects.filter(
                    day_of_week=weekday,
                    is_active=True
                ).first()
                if day_schedule:
                    for slot in day_schedule.time_slots.filter(isOffline=True):  # Only offline slots
                        # Check for conflicting bookings
                        conflicting_bookings = UserSlot.objects.filter(
                            date=current_date,
                            startTime__lt=slot.endTime,
                            endTime__gt=slot.startTime,
                            isOffline=True,
                            payment_status__in=["success", "on hold"]  # Only successful bookings block the slot
                        )
                        if not conflicting_bookings.exists():
                            available_slots.append({
                                'date': current_date,
                                'startTime': slot.startTime,
                                'endTime': slot.endTime,
                                'isOnline': False,
                                'isOffline': True
                            })

            current_date += timedelta(days=1)

        # Sort the slots
        available_slots.sort(key=lambda x: (x['date'], x['startTime']))
        return Response(available_slots, status=status.HTTP_200_OK)
            
#---------------------------------------------------------------Razory pay Details----------------------------------------------------------------


class PaymentVerificationView(APIView):

    permission_classes = [AllowAny]

    def post(self, request):
        razorpay_payment_id = request.data.get('razorpay_payment_id')
        razorpay_order_id = request.data.get('razorpay_order_id')
        razorpay_signature = request.data.get('razorpay_signature')
        # Get payment object
        payment = get_object_or_404(Payment, razorpay_order_id=razorpay_order_id)
        user_slot = payment.user_slot
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        params_dict = {
            'razorpay_payment_id': razorpay_payment_id,
            'razorpay_order_id': razorpay_order_id,
            'razorpay_signature': razorpay_signature
        }
        try:
            # Verify payment signature
            client.utility.verify_payment_signature(params_dict)
            # Update payment and user slot status
            with transaction.atomic():
                payment.status = 'success'
                payment.razorpay_payment_id = razorpay_payment_id
                payment.razorpay_signature = razorpay_signature
                payment.save()
                user_slot.payment_status = 'success'
                user_slot.save()
            # Handle meet link generation separately after payment is confirmed
            meet_link = None
            if user_slot.isOnline:
                try:
                    meet_link = self._generate_meet_link(user_slot)
                    user_slot.meet_link = meet_link
                    user_slot.save()
                except Exception as e:
                    if "Redirect to Google OAuth" in str(e):
                        return Response({
                            'message': 'Payment successful but OAuth authentication required',
                            'status': 'success',
                            'payment_status': 'success',
                            'meet_link_status': 'redirect',
                            'redirect_url': str(e).split(": ")[1]
                        }, status=status.HTTP_302_FOUND)
                    return Response({
                        'message': 'Payment successful but meet link generation failed',
                        'status': 'success',
                        'payment_status': 'success',
                        'meet_link_status': 'failed',
                        'meet_link_error': str(e)
                    }, status=status.HTTP_200_OK)
            return Response({
                'message': 'Payment verified successfully',
                'status': 'success',
                'meet_link': meet_link
            }, status=status.HTTP_200_OK)
        except razorpay.errors.SignatureVerificationError:
            # Handle payment verification failure
            with transaction.atomic():
                payment.status = 'failed'
                payment.save()
                user_slot.payment_status = 'failed'
                user_slot.save()
            return Response({
                'error': 'Payment verification failed',
                'status': 'failed'
            }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({
                'error': str(e),
                'status': 'failed'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        

    #Generating meet link

    def _generate_meet_link(self, user_slot):
        """
        Helper method to generate meet link for online meetings
        """
        meeting_data = {
            'firstName': user_slot.firstName,
            'lastName': user_slot.lastName,
            'email': user_slot.email,
            'isOnline': user_slot.isOnline,
            'isOffline': user_slot.isOffline,
            'startTime': user_slot.startTime,
            'endTime': user_slot.endTime,
            'date': user_slot.date,
            'message': user_slot.message,
            'meet_link': user_slot.meet_link,
            'created_at': user_slot.created_at,
            'payment_status': user_slot.payment_status,
        }
        try:
            return schedule_meeting(meeting_data)
        except Exception as e:
            if "Redirect to Google OAuth" in str(e):
                raise Exception(f"Redirect to Google OAuth: {str(e).split(': ')[1]}")
            raise e


class BookingConfirmationEmailView(APIView):

    permission_classes = [AllowAny]


    def post(self, request):
        try:
            slot_id = request.data.get('id')
            user_slot = get_object_or_404(UserSlot,id=slot_id)
            
            # Common email settings
            subject = "Booking Confirmation"
            from_email = settings.EMAIL_HOST_USER
            recipient_list = [user_slot.email]
            
            # Prepare message based on booking type
            if user_slot.isOnline:
                message = f"""             
                <html>
<head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap');
        
        body {{
            font-family: 'Roboto', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }}
        .container {{
            max-width: 600px;
            margin: 30px auto;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }}
        .header {{
          
            text-align: center;
            padding: 20px;
        }}
        .header h1{{
            color: #026277;
            }}
        .header img {{
            max-width: 300px;
            height: auto;
           
        }}
        .important-notice {{
                    color: #666666;
                    font-weight: bold;
                    margin: 12px 0;
                    text-align: center;
                
                }}
                 .important-notice2 {{
                    color: #666666;
                    
                    margin: 12px 0;
                    text-align: center;
                
                }}
        .header h1 {{
            margin: 10px 0 0;
            font-size: 24px;
            font-weight: 300;
            color: white
        }}
        .content {{
            padding: 30px;
            background-color: #ffffff;
            border-top: 4px solid #026277;

        }}
        .details {{
           background-color: #f9f9f9;
            border-left: 4px solid #026277;
            padding: 20px;
            margin: 20px 0;
            border-radius: 0 8px 8px 0;
        }}
        .details p {{
            margin: 10px 0;
            color: black;
        }}
        .details strong {{
            color: #027378;
            min-width: 100px;
            display: inline-block;
        }}
        .system-notice {{
                    font-family: 'Courier New', monospace;
                    color: #666;
                    font-size: 0.9em;
                    text-align: center;
                    margin: 20px 0;
                    padding: 10px;
                    background-color: #f5f5f5;
                    border-radius: 5px;
                }}
        .meeting-link {{
            display: block;
            text-align: center;
            margin: 20px 0;
        }}
        .meeting-link a {{
            background-color: #027378;
            color: white;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 6px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }}
        .meeting-link a:hover {{
            background-color: #027378;
        }}
        .footer {{
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
            font-size: 0.9em;
            color: #777;
        }}
        .footer p {{
            margin: 5px 0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="https://metabolicresetwithbob.com/static/assets/logo-B9l4SiOc.png" alt="Metabolic Reset With Bob">
            <h1>Consultation Confirmation</h1>
        </div>
        <div class="content">
            <p>Dear {user_slot.firstName},</p>
            <p>Your online consultation slot has been successfully booked. Please find the details below:</p>
            
            <div class="details">
                <p><strong>Date:</strong> {user_slot.date.strftime('%Y-%m-%d')}</p>
                <p><strong>Time:</strong> {user_slot.startTime.strftime('%I:%M %p')} - {user_slot.endTime.strftime('%I:%M %p')}</p>
            </div>
            
            <div class="meeting-link">
                <a href="{user_slot.meet_link}">Join Video Consultation</a>
            </div>
            
            <p class="important-notice2">Please ensure you have a stable internet connection and are in a quiet environment for your consultation. If you need to reschedule, please contact our office at least 24 hours in advance.</p>
        <p class="important-notice">Note: The consultation fee is non-refundable but can be rescheduled.</p>
         </div>
        <div class="footer">
            <p>Best regards,</p>
            <p><strong>Bob Chris</strong></p>
            <p>Metabolic Reset With Bob</p>

            <div class="system-notice">
                This is a system-generated email. Please do not reply to this message.
            </div>

        </div>
    </div>
</body>
</html>
                """
            
            else:
                message = f"""
               <html>
<head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap');
        
        body {{
            font-family: 'Roboto', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }}
         .important-notice {{
                    color: #666666;
                    font-weight: bold;
                    margin: 12px 0;
                    text-align: center;
                
                }}
                 .important-notice2 {{
                    color: #666666;
                    
                    margin: 12px 0;
                    text-align: center;
                
                }}
        .container {{
            max-width: 600px;
            margin: 30px auto;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }}
        .system-notice {{
                    font-family: 'Courier New', monospace;
                    color: #666;
                    font-size: 0.9em;
                    text-align: center;
                    margin: 20px 0;
                    padding: 10px;
                    background-color: #f5f5f5;
                    border-radius: 5px;
                }}
        .header {{
            text-align: center;
            padding: 20px;
        }}

        .header h1{{
                    color: #026277;
                }}

        .header img {{
            max-width: 300px;
            height: auto;
           
        }}
        .content {{
            padding: 30px;
            background-color: #ffffff;
            border-top: 4px solid #026277;
        }}
        .details {{
            background-color: #f9f9f9;
            border-left: 4px solid #026277;
            padding: 20px;
            margin: 20px 0;
            border-radius: 0 8px 8px 0;
        }}
        .details p {{
            margin: 10px 0;
            color:black;
        }}
        .details strong {{
            color: #027378;
            min-width: 100px;
            display: inline-block;
        }}
        .clinic-info {{
            background-color: #e8f5e9;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
            text-align: center;
        }}
        .footer {{
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
            font-size: 0.9em;
            color: #777;
        }}
        .footer p {{
            margin: 5px 0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="https://metabolicresetwithbob.com/static/assets/logo-B9l4SiOc.png" alt="Metabolic Reset With Bob">
            <h1>Consultation Confirmation</h1>
        </div>
        <div class="content">
            <p>Dear {user_slot.firstName},</p>
            <p>Your in-person consultation slot has been successfully booked.</p>
            
            <div class="details">
                <p><strong>Date:</strong> {user_slot.date.strftime('%Y-%m-%d')}</p>
                <p><strong>Time:</strong> {user_slot.startTime.strftime('%I:%M %p')} - {user_slot.endTime.strftime('%I:%M %p')}</p>
            </div>
            
            <div class="clinic-info">
                <p>Please arrive at our clinic 10 minutes before your scheduled time.</p>
                <p><strong>Clinic Address:</strong> H.NO.1920, Sector 34-D, (Near Radio Station)
              Chandigarh - 160034, INDIA</p>
            </div>
            
            <p class="important-notice2">We look forward to providing you with personalized homeopathic care.</p>
            <p class="important-notice">Note: The consultation fee is non-refundable but can be rescheduled.</p>
        </div>
        <div class="footer">
            <p>Best regards,</p>
            <p><strong>Bob Chris</strong></p>
            <p>Metabolic Reset With Bob</p>
             <div class="system-notice">
                This is a system-generated email. Please do not reply to this message.
            </div>

        </div>
    </div>
</body>
</html>
                """
            
            # Send email
            send_mail(
                subject=subject,
                message=message,
                from_email=from_email,
                recipient_list=recipient_list,
                fail_silently=False,
                html_message=message,  # This ensures the email is sent as HTML
            )

            
            return Response({
                "message": "Booking confirmation email sent successfully"
            }, status=status.HTTP_200_OK)
            
        except UserSlot.DoesNotExist:
            return Response({
                "message": "Booking not found"
            }, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({
                "message": "An error occurred while processing your request",
                "error": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        




class OAuth2CallbackView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        try:
            state = request.GET.get('state')
            cached_state = cache.get('oauth_state')
            if not state or state != cached_state:
                return HttpResponse("Invalid state parameter", status=400)

            flow = InstalledAppFlow.from_client_secrets_file(
                os.path.join(settings.BASE_DIR, 'credentials.json'),
                scopes=['https://www.googleapis.com/auth/calendar.events'],
                redirect_uri='https://metabolicresetwithbob.com/oauth2callback'
            )
            flow.fetch_token(code=request.GET.get('code'))
            credentials = flow.credentials

            # Save credentials to database
            token_data = json.loads(credentials.to_json())
            GoogleToken.objects.update_or_create(
                id=1,
                defaults={
                    'token': token_data['token'],
                    'refresh_token': token_data.get('refresh_token'),
                    'token_uri': token_data['token_uri'],
                    'client_id': token_data['client_id'],
                    'client_secret': token_data['client_secret'],
                    'scopes': token_data['scopes'],
                    'expiry': datetime.datetime.fromisoformat(token_data['expiry'].replace('Z', '+00:00')),
                }
            )

            # Clear cached state
            cache.delete('oauth_state')

            # Redirect to a success page or frontend
            return HttpResponseRedirect('https://metabolicresetwithbob.com/booking-success')  # Adjust to your frontend success URL
        except Exception as e:
            return HttpResponse(f"Error in OAuth callback: {str(e)}", status=500)


